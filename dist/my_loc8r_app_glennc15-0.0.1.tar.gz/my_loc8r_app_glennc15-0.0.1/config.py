import os 
from dotenv import load_dotenv


load_dotenv()


class Config:
	SECRETE_KEY = os.environ.get('JWT_SECRETE')
	MAP_KEY = os.environ.get('MAK_KEY') 


	@staticmethod
	def init_app(app):
		pass 


class DevelopmentConfig(Config):
	DEBUG = True 


class TestingConfig(Config):
	TESTING = True 



class ProductionConfig(Config):
	pass 



config = {
	'development': DevelopmentConfig,
	'testing': TestingConfig,
	'production': ProductionConfig,

	'default': DevelopmentConfig
}
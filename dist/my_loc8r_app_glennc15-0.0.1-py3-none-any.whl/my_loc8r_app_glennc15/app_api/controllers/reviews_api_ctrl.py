

def review_create(request, location_id):

	location_data = {
		'location_id': location_id
	}

	return (location_data, 200)

def review_read(request, location_id):

	location_data = {
		'location_id': location_id
	}

	return (location_data, 200)


def review_update(request, location_id):

	location_data = {
		'location_id': location_id
	}

	return (location_data, 200)


def review_delete(request, location_id):

	location_data = {
		'location_id': location_id
	}

	return (location_data, 200)
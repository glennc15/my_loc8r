from project import create_app

application = create_app()
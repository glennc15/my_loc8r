(function() {


angular
	.module('myLoc8rApp')
	.controller('homeCtrl', homeCtrl);

function homeCtrl() {
	var vm = this;

	// the home controller is not doing anything.  But leaving it as it might be used in the future.
	
};




})();
from my_loc8r_app_glennc15 import create_app

application = create_app()